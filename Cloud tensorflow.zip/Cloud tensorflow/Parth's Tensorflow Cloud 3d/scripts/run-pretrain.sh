python3 pretrain.py --group=0 --model=orig-pre --arch=original --lr=1e-2 --toIt=500000
# python3 pretrain.py --group=0 --model=resnet-pre --arch=resnet --lr=1e-2 --toIt=500000
