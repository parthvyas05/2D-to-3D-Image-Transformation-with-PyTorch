python3 evaluate.py --group=0 --arch=original --load=orig-ft_it100000
# python3 evaluate.py --group=0 --arch=resnet --load=resnet-ft_it100000
