python3 evaluate_dist.py --group=0 --load=orig-ft_it100000
# python3 evaluate_dist.py --group=0 --load=resnet-ft_it100000
