python3 densify.py /dataset/ShapeNetCore.v2 $1 $1.list
# python3 densify.py /dataset/ShapeNetCore.v2 03001627 03001627.list

# ./run.sh 03001627
